create DATABASE AMAZON;
USE  AMAZON;

SELECT * FROM amazon_SALES LIMIT 5;


# Add a new column named timeofday to give insight of sales in the Morning, Afternoon and Evening.#

ALTER table amazon_SALES 
ADD column TIMEOFDAY varchar(15) ;
UPDATE amazon_SALES SET TIMEOFDAY  =  CASE 
	WHEN tIME BETWEEN 
    4 AND 11 THEN "MORNING"
	WHEN tIME BETWEEN 12 AND 16 THEN "AFTERNOON"
	ELSE "EVENING" 
END;
set sql_safe_updates=0;


# Add a new column named dayname that contains the extracted days of the week on which the given transaction took place (Mon, Tue, Wed, Thur, Fri) #
ALTER table amazon_SALES 
ADD column DAYOFWeek varchar(15) ;
UPDATE amazon_SALES SET DAYOFWeek  = dayname(DATE) ;


# Add a new column named monthname that contains the extracted months of the year on which the given transaction took place (Jan, Feb, Mar).
ALTER table amazon_SALES 
ADD column monthname varchar(15) ;
UPDATE amazon_SALES SET monthname  = monthname(DATE) ;

# What is the count of distinct cities in the dataset?
SELECT count(distinct CITY) FROM amazon_SALES;



# For each branch, what is the corresponding city?
select distinct branch,city from amazon_sales;



# What is the count of distinct product lines in the dataset?
show columns from amazon_sales;
alter table amazon_sales
rename column `Invoice ID` to Invoice_ID;

alter table amazon_sales
rename column `gross income` to gross_income;

select  count(distinct Product_line) from amazon_sales;



# Which payment method occurs most frequently?
select  payment , count(*) as count from amazon_sales group by payment order by count desc limit 1;



# Which product line has the highest sales?
select product_line , count(*) as no_of_sales from amazon_sales group by product_line order by no_of_sales desc limit 3;



# How much revenue is generated each month?
select	monthname,sum(total) as revenue from amazon_sales group by monthname;



# In which month did the cost of goods sold reach its peak?
select monthname, sum(cogs) as Total_cog from amazon_sales group by monthname order by Total_cog desc limit 1;



# Which product line generated the highest revenue?
select product_line , sum(total) as revenue from amazon_sales group by product_line order by revenue desc limit 3;



# In which city was the highest revenue recorded?
select city , sum(total) as revenue from amazon_sales group by city order by revenue desc limit 1;



# Which product line incurred the highest Value Added Tax?
select product_line,tax from amazon_sales order by tax desc;




# For each product line, add a column indicating "Good" if its sales are above average,otherwise "Bad."
select product_line, 
case 
when average_sales >(select avg(total) from amazon_sales) then "good"
else "bad" end as indication from
(select product_line, avg(total) as average_sales
 from amazon_sales group by product_line) as T;



# Identify the branch that exceeded the average number of products sold.
select branch,avg(quantity) as avg_products 
from amazon_sales 
group by branch having avg_products > (select avg(quantity) from amazon_sales)
;


# Which product line is most frequently associated with each gender?
select product_line,gender, count(*) as freq from amazon_sales  
where gender ="male"
group by product_line,gender

having freq =(select max(freq ) from 
(
select product_line,gender, count(*) as freq from amazon_sales   where gender ="male"
group by product_line,gender
) as sub
);
select product_line,gender, count(*) as freq from amazon_sales  
where gender ="female"
group by product_line,gender

having freq =(select max(freq ) from 
(
select product_line,gender, count(*) as freq from amazon_sales   where gender ="female"
group by product_line,gender
) as sub
)
;
 
 
 
#Calculate the average rating for each product line.
select product_line, avg(rating) as avg_ratig 
from amazon_sales  group by product_line;



# Count the sales occurrences for each time of day on every weekday.
select dayofweek,timeofday,count(*) as sales from 
amazon_sales  group by dayofweek,timeofday
order by dayofweek,timeofday;

;



#Identify the customer type contributing the highest revenue.
select customer_type , sum(total) from amazon_sales
group by customer_type order by customer_type desc limit 1;



# Determine the city with the highest VAT percentage.
select city, tax from amazon_sales order by tax desc;



#Identify the customer type with the highest VAT payments.
select customer_type,sum(tax) as vat from amazon_sales
 group by customer_type order by vat desc limit 1;



# What is the count of distinct customer types in the dataset?
select count(distinct customer_type) from amazon_sales;



# What is the count of distinct payment methods in the dataset?
select count(distinct payment) as count from amazon_sales;



#Which customer type occurs most frequently?
select customer_type,count(*) as count from amazon_sales 
group by customer_type order by count desc limit 1;



#Identify the customer type with the highest purchase frequency.
select customer_type from amazon_sales 
group by customer_type order by count(*) desc limit 1;



#Determine the predominant gender among customers.
select gender from amazon_sales 
group by gender order by count(*) desc limit 1;



#Examine the distribution of genders within each branch.
with male
 as (
 select branch ,count(*) as male_count from amazon_sales 
where gender="male" group by branch)  ,
female as
(select branch ,count(*) as female_count from amazon_sales 
where gender="female" group by branch)
select male.branch,male_count,female_count from male inner join female using(branch);

# Identify the time of day when customers provide the most ratings.
select timeofday ,count(rating) as cnt from amazon_sales 
group by timeofday order by cnt desc;


# Determine the time of day with the highest customer ratings for each branch.
select	branch, timeofday ,count(rating) as cnt 
  from amazon_sales
  group by timeofday,branch having
  cnt= (select max(cnt) from 
  (
  select branch, timeofday ,count(rating) as cnt 
  from amazon_sales
  group by timeofday,branch
  ) as sub
  where sub.branch=amazon_sales.branch);



#Identify the day of the week with the highest average ratings.
select dayofweek,avg(rating) as avgR 
from amazon_sales group by dayofweek
having avgr=(select max(avgr) from 
(
select dayofweek,avg(rating) as avgR 
from amazon_sales group by dayofweek
)
as sub
);





# Determine the day of the week with the highest average ratings for each branch.

select branch, dayofweek, avg(rating) as avgs from amazon_sales
 group by dayofweek,branch 
 having avgs=(select max(avgs) from
 (select branch, dayofweek, avg(rating) as avgs from amazon_sales
 group by dayofweek,branch) as sub 
 where sub.branch=amazon_sales.branch)
 order by avgs desc
 ;







